<?php
require_once __DIR__ . '/../common.php';
security_headers();
start_secure_session();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Student Portal Lab</title></head>
<body>
<h1>Simulated Student Information Portal</h1>
<?php if (!empty($_SESSION['user_id'])): ?>
<p>Signed in as <?= e($_SESSION['name'] ?? '') ?> (<?= e($_SESSION['role'] ?? '') ?>)</p>
<p><a href="record.php">View my academic record</a> | <a href="logout.php">Logout</a></p>
<?php else: ?>
<p><a href="login.php">Login</a></p>
<?php endif; ?>
</body></html>
