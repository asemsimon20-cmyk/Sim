<?php
require_once __DIR__ . '/../common.php';
security_headers();
require_login();
$pdo = db();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = trim($_POST['body'] ?? '');
    if ($body !== '' && mb_strlen($body) <= 2000) {
        $stmt = $pdo->prepare('INSERT INTO forum_posts(user_id,course_id,body) VALUES(?,?,?)');
        $stmt->execute([(int)$_SESSION['user_id'], 1, $body]);
        log_event('forum_post_created');
        header('Location: forum.php'); exit;
    }
}
$posts = $pdo->query('SELECT p.body,p.created_at,u.full_name FROM forum_posts p
    JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 50')->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>LMS Forum</title></head><body>
<h1>Course Discussion Forum</h1>
<form method="post"><label>Comment<br><textarea name="body" maxlength="2000" required></textarea></label>
<button type="submit">Post</button></form>
<h2>Recent posts</h2>
<?php foreach ($posts as $post): ?>
<article><strong><?= e($post['full_name']) ?></strong>
<p><?= nl2br(e($post['body'])) ?></p>
<small><?= e($post['created_at']) ?></small></article><hr>
<?php endforeach; ?>
</body></html>
