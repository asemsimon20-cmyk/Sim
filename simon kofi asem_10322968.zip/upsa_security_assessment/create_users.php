<?php
require_once __DIR__ . '/common.php';

$seed = [
 ['Lab Administrator','admin@example.test','AdminLab!2026','admin'],
 ['Student One','student1@example.test','StudentLab!2026','student'],
 ['Student Two','student2@example.test','StudentLab!2026','student'],
 ['Lab Lecturer','lecturer@example.test','LecturerLab!2026','lecturer']
];

$pdo = db();
foreach ($seed as [$name,$email,$password,$role]) {
    $stmt = $pdo->prepare('INSERT INTO users(full_name,email,password_hash,role)
        VALUES(:n,:e,:p,:r) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name)');
    $stmt->execute([
        ':n'=>$name, ':e'=>$email,
        ':p'=>password_hash($password, PASSWORD_DEFAULT), ':r'=>$role
    ]);
}
$students = $pdo->query("SELECT id,email FROM users WHERE role='student'")->fetchAll();
foreach ($students as $i=>$s) {
    $stmt = $pdo->prepare('INSERT IGNORE INTO student_records
        (user_id,student_number,programme,level,gpa) VALUES(?,?,?,?,?)');
    $stmt->execute([$s['id'], 'LAB'.str_pad((string)($i+1),4,'0',STR_PAD_LEFT),
        'BSc Information Technology','300',3.45]);
}
echo 'Lab users created. DELETE create_users.php now.';
