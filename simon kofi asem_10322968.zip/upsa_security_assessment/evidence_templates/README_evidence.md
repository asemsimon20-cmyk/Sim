# Evidence capture guidance
For each test, record date/time, lab target, exact steps, expected result, observed result and screenshot filename.
Mask credentials and personal data. Do not scan or test live UPSA systems or third-party systems.
Use only your local XAMPP lab or another explicitly authorized environment.
