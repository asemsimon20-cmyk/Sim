<?php
require_once __DIR__ . '/../common.php';
security_headers();
require_login();

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['learning_file']) || $_FILES['learning_file']['error'] !== UPLOAD_ERR_OK) {
        $message = 'Upload failed.';
    } elseif ($_FILES['learning_file']['size'] > 5 * 1024 * 1024) {
        $message = 'Maximum file size is 5 MB.';
    } else {
        $allowed = [
            'application/pdf' => 'pdf',
            'image/jpeg' => 'jpg',
            'image/png' => 'png'
        ];
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($_FILES['learning_file']['tmp_name']);
        if (!isset($allowed[$mime])) {
            $message = 'File type not allowed.';
            log_event('upload_rejected', 'mime='.$mime);
        } else {
            // Store outside the public web root in a real deployment.
            $storage = dirname(__DIR__) . '/private_uploads';
            if (!is_dir($storage)) mkdir($storage, 0700, true);
            $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
            if (move_uploaded_file($_FILES['learning_file']['tmp_name'], $storage.'/'.$name)) {
                $message = 'File passed basic validation and was stored.';
                log_event('upload_accepted', 'stored_name='.$name);
            } else {
                $message = 'Could not store file.';
            }
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Secure Upload</title></head><body>
<h1>LMS Secure File Upload</h1>
<p><?= e($message) ?></p>
<form method="post" enctype="multipart/form-data">
<input type="file" name="learning_file" accept=".pdf,.jpg,.jpeg,.png" required>
<button type="submit">Upload</button></form>
<p>Allowed: PDF, JPEG, PNG. Maximum: 5 MB.</p></body></html>
