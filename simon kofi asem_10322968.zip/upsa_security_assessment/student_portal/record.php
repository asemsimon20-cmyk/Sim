<?php
require_once __DIR__ . '/../common.php';
security_headers();
require_login();

$requestedId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($requestedId === false || $requestedId === null) {
    $requestedId = (int)$_SESSION['user_id'];
}

// Students can only view their own record. Staff access is explicitly role-gated.
if (($_SESSION['role'] ?? '') === 'student' && $requestedId !== (int)$_SESSION['user_id']) {
    log_event('record_access_denied', 'requested_user_id='.$requestedId);
    http_response_code(403);
    exit('Access denied: students may only view their own record.');
}
if (!in_array($_SESSION['role'] ?? '', ['student','lecturer','admin'], true)) {
    http_response_code(403); exit('Access denied.');
}
$stmt = db()->prepare('SELECT u.full_name,r.student_number,r.programme,r.level,r.gpa
    FROM student_records r JOIN users u ON u.id=r.user_id WHERE r.user_id=:id');
$stmt->execute([':id'=>$requestedId]);
$row = $stmt->fetch();
if (!$row) { http_response_code(404); exit('Record not found.'); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Academic Record</title></head><body>
<h1>Academic Record</h1>
<p>Name: <?= e($row['full_name']) ?></p>
<p>Student number: <?= e($row['student_number']) ?></p>
<p>Programme: <?= e($row['programme']) ?></p>
<p>Level: <?= e($row['level']) ?></p>
<p>GPA: <?= e((string)$row['gpa']) ?></p>
<p><a href="index.php">Home</a></p></body></html>
