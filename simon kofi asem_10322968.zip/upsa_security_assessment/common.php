<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

function security_headers(): void {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: default-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
    // Enable HSTS only after HTTPS is correctly configured:
    // header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}

function start_secure_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps, // true on HTTPS; localhost HTTP lab remains usable
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function log_event(string $event, string $detail = ''): void {
    $dir = __DIR__ . '/logs';
    if (!is_dir($dir)) mkdir($dir, 0700, true);
    $line = date('c') . ' event=' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $event)
          . ' user_id=' . ($_SESSION['user_id'] ?? 'anonymous')
          . ' ip=' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown')
          . ' detail=' . str_replace(["\r", "\n"], ' ', $detail) . PHP_EOL;
    file_put_contents($dir . '/security.log', $line, FILE_APPEND | LOCK_EX);
}

function require_login(): void {
    start_secure_session();
    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        exit('Please log in first.');
    }
}

function require_role(array $roles): void {
    require_login();
    if (!in_array($_SESSION['role'] ?? '', $roles, true)) {
        log_event('authorization_denied', $_SERVER['REQUEST_URI'] ?? '');
        http_response_code(403);
        exit('Access denied.');
    }
}
