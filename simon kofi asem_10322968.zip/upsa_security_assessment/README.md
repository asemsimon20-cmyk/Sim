# UPSA Simulated Security Assessment Practical Pack

**Scope:** Local, authorized lab only. This pack is designed for XAMPP on your own computer.
It does not connect to, scan, or test real UPSA systems or any third-party target.

## Requirements
- XAMPP (Apache + MySQL/MariaDB + PHP)
- PHP extensions: PDO MySQL, fileinfo
- Optional: Kali Linux or another machine for Nmap / OWASP ZAP testing
- A modern browser

## Setup
1. Start Apache and MySQL in XAMPP.
2. Copy this whole `upsa_security_assessment` folder into `C:\xampp\htdocs\`.
3. Open phpMyAdmin at `http://127.0.0.1/phpmyadmin`.
4. Import `database.sql`.
5. Open `http://127.0.0.1/upsa_security_assessment/student_portal/`.
6. Open `http://127.0.0.1/upsa_security_assessment/lms/`.

If you use a different folder name, update the URLs accordingly.

## Lab accounts
After importing the database, create accounts using `create_users.php` once:
- admin@example.test / AdminLab!2026
- student1@example.test / StudentLab!2026
- student2@example.test / StudentLab!2026
- lecturer@example.test / LecturerLab!2026

Open `http://127.0.0.1/upsa_security_assessment/create_users.php` once, then DELETE that file.
These are disposable lab credentials. Never reuse them.

## Practical exercises
1. SQL injection prevention: `student_portal/login.php` uses PDO prepared statements.
2. Authentication: password hashes and PHP `password_verify()`.
3. Authorization / IDOR: `student_portal/record.php?id=2` enforces student ownership; test with student1 and student2.
4. Security headers: inspect response headers on portal pages.
5. Secure file upload: LMS allows only PDF/JPEG/PNG, validates MIME, limits size, uses random names, stores outside public uploads when configured.
6. XSS prevention: forum comments are rendered with `htmlspecialchars()`.
7. Session security: secure cookie settings, session ID regeneration, logout invalidation.
8. Logging: events are written to `logs/security.log` (restrict access in real deployment).

## Nmap (localhost only)
Find the local XAMPP service ports:
`nmap -sV -p 80,443,3306 127.0.0.1`

Do not change the target to a public IP, UPSA host, or any third-party system without written authorization.

## OWASP ZAP
Use ZAP only against the local lab URL:
`http://127.0.0.1/upsa_security_assessment/`
Start with a passive scan. Use active scanning only when you own the lab and understand the impact.
Do not submit real personal data.

## Evidence
Use the templates in `evidence_templates/`. Capture screenshots of your own test results and replace illustrative observations in the report with what you actually observe.
