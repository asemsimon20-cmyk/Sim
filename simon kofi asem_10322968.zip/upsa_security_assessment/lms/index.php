<?php
require_once __DIR__ . '/../common.php';
security_headers();
start_secure_session();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>LMS Lab</title></head><body>
<h1>Simulated Learning Management System</h1>
<?php if (empty($_SESSION['user_id'])): ?>
<p><a href="../student_portal/login.php">Login using a lab account</a></p>
<?php else: ?>
<p>Welcome <?= e($_SESSION['name'] ?? '') ?>.</p>
<p><a href="forum.php">Discussion forum</a></p>
<?php if (in_array($_SESSION['role'], ['student','lecturer','admin'], true)): ?>
<p><a href="upload.php">Upload learning file</a></p>
<?php endif; ?>
<p><a href="../student_portal/logout.php">Logout</a></p>
<?php endif; ?>
</body></html>
