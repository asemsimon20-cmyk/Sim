<?php
require_once __DIR__ . '/../common.php';
security_headers();
start_secure_session();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'Enter a valid email and password.';
    } else {
        // Prepared statement prevents user input becoming SQL syntax.
        $stmt = db()->prepare('SELECT id,full_name,email,password_hash,role FROM users WHERE email=:email');
        $stmt->execute([':email'=>$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            log_event('login_success');
            header('Location: index.php'); exit;
        }
        log_event('login_failure', $email);
        $error = 'Invalid credentials.';
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Portal Login</title></head><body>
<h1>Student Portal Login</h1>
<?php if ($error): ?><p role="alert"><?= e($error) ?></p><?php endif; ?>
<form method="post">
<label>Email <input type="email" name="email" required></label><br>
<label>Password <input type="password" name="password" required></label><br>
<button type="submit">Sign in</button>
</form></body></html>
